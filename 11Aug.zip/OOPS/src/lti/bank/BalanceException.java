package lti.bank;

public class BalanceException extends Exception {

	public BalanceException() {
		super();
		
	
		
	}

	public BalanceException(String arg0) {
		super(arg0);
		
	}

	
	
}
