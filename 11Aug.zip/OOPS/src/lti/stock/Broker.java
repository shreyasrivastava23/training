package lti.stock;

public interface Broker extends Holder {
	public void getQuote();
}
