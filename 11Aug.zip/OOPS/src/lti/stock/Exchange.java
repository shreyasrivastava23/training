package lti.stock;

public interface Exchange extends Broker {
 public void setQuote();

}
