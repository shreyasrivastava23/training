package lti.stock;

public interface Holder{
public void viewQuote();

}
