package lti.lib;

public class Member {
	
	String name;

	public Member() {
		// TODO Auto-generated constructor stub
	}
	
	public Member(String name)
	{
		
	}
}
