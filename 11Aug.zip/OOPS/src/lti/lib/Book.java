package lti.lib;

public class Book
{
	String title;
	
	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	public Book(String title)
	{
		
	}

}
