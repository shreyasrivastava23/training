
public class StaticImport {

}
