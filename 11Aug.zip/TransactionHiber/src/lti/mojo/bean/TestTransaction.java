package lti.mojo.bean;

public class TestTransaction {

}
