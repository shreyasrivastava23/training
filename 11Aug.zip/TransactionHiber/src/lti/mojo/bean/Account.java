package lti.mojo.bean;

import java.util.Vector;



public class Account {
	private int accNo;
	private String holder;
	protected double balance;
	static int INIT_ACNT_NO=1001;

	protected int idx;
	Vector<Transaction> vtr = new Vector<>();
	private static int autogen = INIT_ACNT_NO;

	public Account() {
	}

	public Account(String holder, double balance) {

		this.accNo = autogen++;
		this.holder = holder;
		this.balance = balance;


	}

	public void summary() {
		System.out.println("A/c No: " + accNo);
		System.out.println("Holder: " + holder);
		System.out.println("Balance: " + balance);
	}

	public double getBalance() {
		return balance;
	}

	public void deposit(double amount) {
		balance += amount;
		vtr.add(new Transaction("Cr", amount, balance));
	}

	public void statement() {
		System.out.println("Statement of Acc. " + accNo);

		for (Transaction t : vtr)
			System.out.println(t);
	
		System.out.println("\n\n\n");
	}

}
