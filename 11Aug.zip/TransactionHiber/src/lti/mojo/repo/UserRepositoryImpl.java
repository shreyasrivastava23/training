package lti.mojo.repo;

public interface UserRepositoryImpl {

}
