package lti.mojo.repo;

public class UserRepository {

}
