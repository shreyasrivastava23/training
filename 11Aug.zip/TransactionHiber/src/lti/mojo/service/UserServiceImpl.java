package lti.mojo.service;

public interface UserServiceImpl {

}
