package lti.mojo.service;

public class UserService {

}
