package lti.hola.service;

import lti.hola.bean.forgetBean;
import lti.hola.bean.loginBean;
import lti.hola.bean.registerBean;

public interface UserService {
 
	
	registerBean authenticate(loginBean login);
 
 boolean validate(forgetBean forget);
 boolean changePassword(loginBean login);
 boolean persist(registerBean register);

}

