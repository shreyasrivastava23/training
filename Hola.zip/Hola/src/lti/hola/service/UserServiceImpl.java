package lti.hola.service;

import java.util.Base64;
import java.util.Base64.Encoder;

import lti.hola.bean.forgetBean;
import lti.hola.bean.loginBean;
import lti.hola.bean.registerBean;
import lti.hola.repo.UserRepository;
import lti.hola.repo.UserRepositoryImpl;

public class UserServiceImpl implements UserService {

	private UserRepository repo;

	public UserServiceImpl() {
		repo = new UserRepositoryImpl();
	}

	public registerBean authenticate(loginBean login) {

		// Password encoding
		Encoder encoder = Base64.getEncoder();
		String encoded = encoder.encodeToString(login.getPassword().getBytes());
		login.setPassword(encoded);
		return repo.authenticate(login);
	}

	public boolean validate(forgetBean forget) {
		// Movie encoding
		Encoder encoder = Base64.getEncoder();
		forget.setMovie(encoder.encodeToString(forget.getMovie().getBytes()));
		return repo.validate(forget);

	}

	public boolean changePassword(loginBean login) {

		// Password encoding
		Encoder encoder = Base64.getEncoder();
		login.setPassword(encoder.encodeToString(login.getPassword().getBytes()));
		return repo.changePassword(login);

	}

	public boolean persist(registerBean register) {
		// Password and movie encoding
		Encoder encoder = Base64.getEncoder();
		register.setPassword(encoder.encodeToString(register.getPassword().getBytes()));
		register.setMovie(encoder.encodeToString(register.getMovie().getBytes()));
		return repo.persist(register);
	}

}
