package lti.hola.web;

import javax.servlet.http.HttpServletRequest;

import lti.hola.bean.forgetBean;
import lti.hola.bean.loginBean;
import lti.hola.bean.registerBean;
import lti.hola.service.UserService;
import lti.hola.service.UserServiceImpl;

public class LoginController {

	public static registerBean autheticate(HttpServletRequest request) {
		UserService service = new UserServiceImpl();

		// Instantiating loginbean to hold login credentials
		loginBean login = new loginBean();

		// reading request parameters and storing in loginbean object
		login.setEmail(request.getParameter("email"));
		login.setPassword(request.getParameter("password"));

		// Passing loginBean object to service method
		registerBean user = service.authenticate(login);
		return user;

	}

	public static boolean changePassword(HttpServletRequest request) {

		UserService service = new UserServiceImpl();
		loginBean change = new loginBean();
		// Reading request parameter and storing in login bean object
		change.setEmail(request.getParameter("email"));
		change.setPassword(request.getParameter("password"));
		return service.changePassword(change);
	}

	public static boolean forgetPassword(HttpServletRequest request) {
		UserService service = new UserServiceImpl();
		forgetBean forget = new forgetBean();
		forget.setEmail(request.getParameter("email"));
		forget.setMovie(request.getParameter("movie"));
		return service.validate(forget);
	}

}
