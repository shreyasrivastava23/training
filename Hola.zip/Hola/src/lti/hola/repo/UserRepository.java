package lti.hola.repo;

import lti.hola.bean.forgetBean;
import lti.hola.bean.loginBean;
import lti.hola.bean.registerBean;

/**
 * Repository interface for variety of database
 * @author Shreya Deeksha
 *
 */
public interface UserRepository {
	
registerBean authenticate(loginBean login);
 
 boolean validate(forgetBean forget);

 boolean changePassword(loginBean login);
 
 boolean persist(registerBean register);

}
