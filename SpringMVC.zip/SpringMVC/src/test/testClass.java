package test;

public class testClass {

	public void testController() {
		
	}
}
